# Configuration Guide

The central configuration file is `config/dimbuilder.yaml`. It is merged with `defaultAppConfig` from `src/shared/appConfigDefaults.ts`, validated by `src/shared/appConfigValidation.ts`, and loaded at server startup by `src/server/config/loadAppConfig.ts`.

## Load Order

1. Start with `defaultAppConfig`.
2. Read YAML from `DIMBUILDER_CONFIG_FILE` or `config/dimbuilder.yaml`.
3. Deep-merge YAML over defaults.
4. Apply supported environment overrides.
5. Validate the final `AppConfig`.

## Main Sections

### `application`

Controls product identity and user-facing app text. The default product name is "Spaulding Ridge Onestream Dim Builder".

Important fields:

- `productName`
- `applicationName`
- `title`
- `description`
- `environmentName`
- `oneStreamVersionFallback`
- `supportText`

### `paths`

Controls local storage locations.

- `metadataDirectory`: XML reference directory.
- `defaultMetadataFile`: preferred XML reference file.
- `uploadsDirectory`: uploaded workbook directory.
- `exportsDirectory`: generated exports directory.
- `databaseFile`: SQLite database path.

### `server`

Controls host, ports, and CORS.

- `host`
- `port`
- `clientDevPort`
- `corsOrigins`: optional string array of allowed CORS origins. When set, the server restricts `Access-Control-Allow-Origin` to these values. When absent, CORS is open (see `src/server/app.ts:25`).

### `auth`

Controls HTTP Basic Authentication.

- `enabled`: boolean, default `false`. When true, all `/api/*` routes (except `/api/health`) require Basic Auth credentials.
- `username`: string, default `"admin"`.
- `password`: string, default `"changeme"`.

The auth middleware is defined in `src/server/middleware/basicAuth.ts`. When disabled, it is a no-op passthrough. The `auth` section is server-only and excluded from the client config payload (`src/shared/appConfigValidation.ts:262`).

### `features`

Enables or disables app capabilities:

- metadata reference alignment
- metadata-only dimensions
- XML preview
- XLSX export
- CSV export
- JSON backup
- audit log
- snapshots

### `dimensions`

Defines supported dimension types, display order, display labels, metadata-only behavior, sheet aliases, preferred metadata names, and blueprints.

The supported dimension types are defined in `src/shared/types.ts` and `src/shared/dimensionSchemas.ts`:

- `Scenario`
- `Entity`
- `Account`
- `Flow`
- `UD1` through `UD8`

Blueprint drafts can be authored with Blueprint Studio from the dashboard. The Studio validates drafts through `src/shared/blueprintStudio.ts` and returns YAML fragments, but it does not automatically mutate `config/dimbuilder.yaml`.

### `import`

Controls XLSX parser behavior and metadata reference alignment.

### `validation`

Controls generic validation severities, the OneStream-specific design-quality profile, and which severities block export.

OneStream profile defaults:

```yaml
validation:
  oneStreamProfile:
    enabled: true
    memberNameMaxLength: 250
    warnOnMemberNameSpaces: true
    warnOnMemberNamePeriods: true
    reservedWords:
      - Root
      - None
    restrictedCharacters:
      - "<"
      - ">"
      - "\""
      - "'"
      - "&"
      - "|"
      - "["
      - "]"
    duplicateAliasSeverity: warning
    invalidSortOrderSeverity: warning
    sharedMemberSeverity: info
    parentInputWarningSeverity: warning
    unknownPropertySeverity: warning
    invalidEnumSeverity: error
    invalidPropertyTypeSeverity: error
```

The profile adds OneStream-aware warnings for naming conventions, aliases, Root/None casing, sort order, shared members, parent input, missing Account Type, missing Entity Currency, missing relationship weights, and invalid Entity ownership percentages.

### `export`

Controls XML, XLSX, CSV, and JSON export availability and options.

Validation gate fields:

- `allowValidationBypass`: optional boolean, default `false`; allows explicit server-side export bypass when blocking validation issues exist.
- `validationBypassRequiresReason`: optional boolean, default `true`; requires a bypass reason when bypass is enabled.
- `requireValidationBeforeExport`: optional boolean, default `false`; when true, exports are blocked until validation has run at least once.

### `ui`

Controls default workspace tab, grid page size, toolbar visibility, and XML preview defaults.

## Validation Rules

`validateAppConfig()` rejects:

- unknown dimension types in enabled types, display order, sheet aliases, preferred metadata names, or blueprints
- missing or invalid blueprint objects
- unsupported blueprint member key fields
- invalid blueprint member or relationship fields
- invalid relationship default types
- invalid Blueprint Studio drafts, because they are normalized and checked with the same blueprint validation rules before YAML is generated
- invalid severities
- invalid `validation.oneStreamProfile` booleans, positive integer limits, string arrays, or severities
- non-boolean export validation gate fields
- invalid TCP ports
- non-positive grid page size
- invalid metadata-only exclude regex patterns

## Environment Overrides

The loader currently supports these environment overrides:

```text
DIMBUILDER_CONFIG_FILE
METADATA_DIRECTORY
DATABASE_FILE
PORT
```

Environment overrides should remain small and operational. Functional behavior should stay in YAML so it can be reviewed and documented.

## Frontend Config Editor

The app includes a browser-based config editor accessible from the "Config" section in the sidebar. It displays the current merged configuration as JSON in an editable textarea. Clicking "Save" sends a `PUT /api/config` request that writes the updated values to the YAML file and hot-reloads the configuration without restarting the server.

This is useful for making quick configuration tweaks (e.g., toggling features, adjusting validation severities, or changing export options) without SSH access or manual YAML editing. The editor respects the same validation rules as the YAML loader — invalid configurations are rejected with a descriptive error.
